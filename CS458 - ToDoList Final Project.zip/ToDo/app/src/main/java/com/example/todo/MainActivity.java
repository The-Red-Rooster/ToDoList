package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;

import com.example.todo.AddNewTodo;
import com.example.todo.Adapter.taskAdapter;
import com.example.todo.Model.TaskModel;
import com.example.todo.Utils.DBHandler;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DialogCloseListener{

    private DBHandler db;
    private RecyclerView toDoRecyclerView;
    private taskAdapter toDoAdapter;

    private List<TaskModel>toDoList;
    private FloatingActionButton fab;

    private List<TaskModel> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        db = new DBHandler(this);
        db.openDatabase();

        toDoList = new ArrayList<>();

        toDoRecyclerView = findViewById(R.id.toDoRecyclerView);
        toDoRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        toDoAdapter = new taskAdapter(db, this);
        toDoRecyclerView.setAdapter(toDoAdapter);

        ItemTouchHelper itemTouchHelper = new
                ItemTouchHelper(new RecyclerItemTouchHelper(toDoAdapter));
        itemTouchHelper.attachToRecyclerView(toDoRecyclerView);

        fab = findViewById(R.id.floatButton);

        taskList = db.getAllTasks();
        Collections.reverse(taskList);

        toDoAdapter.setTask(taskList);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddNewTodo.newInstance().show(getSupportFragmentManager(), AddNewTodo.TAG);
            }
        });

    }

    @Override
    public void handleDialogClose(DialogInterface dialog){
        taskList = db.getAllTasks();
        Collections.reverse(taskList);
        toDoAdapter.setTask(taskList);
        toDoAdapter.notifyDataSetChanged();
    }
}